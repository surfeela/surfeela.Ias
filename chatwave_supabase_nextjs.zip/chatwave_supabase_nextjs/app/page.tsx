import ChatWave from "@/components/chatwave";
import { createClient } from "@/lib/supabase/server";

export default async function Home() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  return <ChatWave initialUser={user ? { id: user.id, phone: user.phone ?? "" } : null} />;
}
