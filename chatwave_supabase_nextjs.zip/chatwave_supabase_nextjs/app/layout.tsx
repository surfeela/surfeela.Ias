import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ChatWave — Private Messaging",
  description: "A messaging app starter built with Next.js and Supabase.",
};
export const viewport: Viewport = { themeColor: "#102a24", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
