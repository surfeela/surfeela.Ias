"use client";

import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type UserLite = { id: string; phone: string; display_name?: string | null };
type Chat = { id: string; kind: "direct" | "group"; title: string | null; updated_at: string };
type Message = { id: string; conversation_id: string; sender_id: string; body: string | null; message_type: string; created_at: string };
type Props = { initialUser: { id: string; phone: string } | null };

export default function ChatWave({ initialUser }: Props) {
  const supabase = useMemo(() => createClient(), []);
  const [user, setUser] = useState(initialUser);
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [chats, setChats] = useState<Chat[]>([]);
  const [activeChat, setActiveChat] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [messageText, setMessageText] = useState("");
  const [people, setPeople] = useState<UserLite[]>([]);
  const [search, setSearch] = useState("");
  const [newPhone, setNewPhone] = useState("");
  const [showNewChat, setShowNewChat] = useState(false);

  const loadChats = useCallback(async () => {
    const { data, error: err } = await supabase
      .from("conversation_members")
      .select("conversation_id, conversations(id, kind, title, updated_at)")
      .eq("user_id", user?.id ?? "");
    if (err) { setError(err.message); return; }
    const rows = (data ?? []).map((row: any) => row.conversations).filter(Boolean) as Chat[];
    setChats(rows.sort((a, b) => b.updated_at.localeCompare(a.updated_at)));
  }, [supabase, user?.id]);

  const loadMessages = useCallback(async (chatId: string) => {
    const { data, error: err } = await supabase
      .from("messages")
      .select("id, conversation_id, sender_id, body, message_type, created_at")
      .eq("conversation_id", chatId)
      .is("deleted_at", null)
      .order("created_at", { ascending: true })
      .limit(300);
    if (err) { setError(err.message); return; }
    setMessages((data ?? []) as Message[]);
  }, [supabase]);

  useEffect(() => {
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      const next = session?.user;
      setUser(next ? { id: next.id, phone: next.phone ?? "" } : null);
    });
    return () => listener.subscription.unsubscribe();
  }, [supabase]);

  useEffect(() => { if (user) void loadChats(); else { setChats([]); setMessages([]); setActiveChat(null); } }, [user, loadChats]);

  useEffect(() => {
    if (!user || !activeChat) return;
    void loadMessages(activeChat);
    const channel = supabase.channel(`messages:${activeChat}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "messages", filter: `conversation_id=eq.${activeChat}` }, () => { void loadMessages(activeChat); })
      .subscribe();
    return () => { void supabase.removeChannel(channel); };
  }, [user, activeChat, supabase, loadMessages]);

  async function sendOtp(e: FormEvent) {
    e.preventDefault(); setBusy(true); setError(""); setNotice("");
    const normalized = phone.trim();
    if (!/^\+[1-9]\d{7,14}$/.test(normalized)) {
      setError("Enter a phone number in international format, for example +923001234567.");
      setBusy(false); return;
    }
    const { error: err } = await supabase.auth.signInWithOtp({ phone: normalized });
    if (err) setError(err.message);
    else { setOtpSent(true); setNotice("Verification code requested. Check your SMS."); }
    setBusy(false);
  }

  async function verifyOtp(e: FormEvent) {
    e.preventDefault(); setBusy(true); setError(""); setNotice("");
    const { data, error: err } = await supabase.auth.verifyOtp({ phone: phone.trim(), token: otp.trim(), type: "sms" });
    if (err) setError(err.message);
    else if (data.user) { setUser({ id: data.user.id, phone: data.user.phone ?? phone.trim() }); setNotice("You are signed in."); }
    setBusy(false);
  }

  async function logout() {
    const { error: err } = await supabase.auth.signOut();
    if (err) setError(err.message);
    setUser(null); setNotice("Signed out.");
  }

  async function sendMessage(e: FormEvent) {
    e.preventDefault();
    if (!user || !activeChat || !messageText.trim()) return;
    setError("");
    const body = messageText.trim();
    setMessageText("");
    const { error: err } = await supabase.from("messages").insert({
      conversation_id: activeChat, sender_id: user.id, body, message_type: "text",
    });
    if (err) { setError(err.message); setMessageText(body); }
    else {
      await supabase.from("conversations").update({ updated_at: new Date().toISOString() }).eq("id", activeChat);
      void loadMessages(activeChat); void loadChats();
    }
  }

  async function findPeople(e: FormEvent) {
    e.preventDefault(); setError(""); setPeople([]);
    const normalized = newPhone.trim();
    if (!normalized) return;
    // The public profiles table must not expose phone numbers broadly.
    // This starter searches exact phone numbers only; adjust policies for your privacy model.
    const { data, error: err } = await supabase.from("profiles")
      .select("id, phone, display_name").eq("phone", normalized).neq("id", user?.id ?? "");
    if (err) setError(err.message);
    else setPeople((data ?? []) as UserLite[]);
    if (!err && !(data ?? []).length) setNotice("No matching profile. The other user may need to sign in first.");
  }

  async function startDirectChat(otherUserId: string) {
    setError(""); setNotice("");
    // Use the security-definer RPC from schema.sql; never create memberships by trusting the browser.
    const { data, error: err } = await supabase.rpc("create_direct_conversation", { other_user_id: otherUserId });
    if (err) { setError(err.message); return; }
    const chatId = data as string;
    await loadChats(); setActiveChat(chatId); setShowNewChat(false); setPeople([]); setNewPhone("");
  }

  const active = chats.find(c => c.id === activeChat);
  const visibleChats = chats.filter(c => (c.title ?? (c.kind === "group" ? "Group chat" : "Direct chat")).toLowerCase().includes(search.toLowerCase()));

  if (!user) return (
    <main className="login-page">
      <section className="login-card">
        <div className="logo">C</div><p className="eyebrow">MESSAGING, REIMAGINED</p>
        <h1>ChatWave</h1><p className="muted">Sign in with your phone to connect.</p>
        {!otpSent ? <form onSubmit={sendOtp}>
          <label htmlFor="phone">Phone number</label>
          <input id="phone" value={phone} onChange={e => setPhone(e.target.value)} placeholder="+923001234567" autoComplete="tel" required />
          <button className="primary" disabled={busy}>{busy ? "Sending…" : "Send verification code"}</button>
        </form> : <form onSubmit={verifyOtp}>
          <label htmlFor="otp">SMS verification code</label>
          <input id="otp" value={otp} onChange={e => setOtp(e.target.value)} placeholder="Enter code" inputMode="numeric" autoComplete="one-time-code" required />
          <button className="primary" disabled={busy}>{busy ? "Verifying…" : "Verify and sign in"}</button>
          <button type="button" className="link-button" onClick={() => { setOtpSent(false); setOtp(""); }}>Change phone number</button>
        </form>}
        {error && <p className="error">{error}</p>}{notice && <p className="notice">{notice}</p>}
        <p className="fine">SMS delivery depends on your Supabase Auth and SMS provider settings.</p>
      </section>
    </main>
  );

  return (
    <main className="app">
      <header className="topbar"><div className="logo small-logo">C</div><div className="brand"><strong>ChatWave</strong><span>Stay connected</span></div><button className="ghost" onClick={logout}>Log out</button></header>
      {(error || notice) && <div className={error ? "alert error" : "alert notice"}>{error || notice}<button onClick={() => {setError("");setNotice("");}}>×</button></div>}
      <div className="layout">
        <aside className={`sidebar ${activeChat ? "mobile-hide" : ""}`}>
          <div className="sidebar-heading"><div><h2>Chats</h2><p className="muted">{user.phone}</p></div><button className="plus" onClick={() => setShowNewChat(v => !v)} aria-label="New chat">＋</button></div>
          <input className="search" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search conversations" />
          {showNewChat && <form className="new-chat" onSubmit={findPeople}><label htmlFor="findPhone">Find user by exact phone</label><input id="findPhone" value={newPhone} onChange={e => setNewPhone(e.target.value)} placeholder="+923001234567" required/><button className="primary">Search users</button>
            {people.map(p => <button type="button" className="person-result" key={p.id} onClick={() => void startDirectChat(p.id)}><span className="avatar">{(p.display_name || p.phone).slice(0,1).toUpperCase()}</span><span>{p.display_name || p.phone}<small>{p.phone}</small></span></button>)}
          </form>}
          <div className="chat-list">{visibleChats.map(chat => <button className={`chat-item ${activeChat === chat.id ? "selected" : ""}`} key={chat.id} onClick={() => setActiveChat(chat.id)}>
            <span className="avatar">{(chat.title || (chat.kind === "group" ? "G" : "D")).slice(0,1).toUpperCase()}</span>
            <span className="chat-label"><strong>{chat.title || (chat.kind === "group" ? "Group chat" : "Direct chat")}</strong><small>{chat.kind === "group" ? "Group conversation" : "Private conversation"}</small></span>
          </button>)}
          {!visibleChats.length && <p className="muted empty-list">No conversations yet. Use + to find a user.</p>}</div>
        </aside>
        <section className={`conversation ${activeChat ? "show-mobile" : ""}`}>
          {!activeChat ? <div className="welcome"><div className="welcome-symbol">◌</div><h2>Your messages, in one place</h2><p>Choose a chat or find another user to begin.</p></div> : <>
            <header className="conversation-head"><button className="back ghost" onClick={() => setActiveChat(null)}>‹</button><div className="avatar">{(active?.title || "C").slice(0,1).toUpperCase()}</div><div className="person-title"><strong>{active?.title || (active?.kind === "group" ? "Group chat" : "Direct chat")}</strong><small>{active?.kind === "group" ? "Group" : "Conversation"}</small></div><button className="ghost call-button" onClick={() => setNotice("Calling UI is the next phase. Real voice/video/group calls need WebRTC signaling and media infrastructure.")}>Call</button></header>
            <div className="messages">{messages.map(m => <div className={`message ${m.sender_id === user.id ? "mine" : ""}`} key={m.id}><div>{m.body || `[${m.message_type}]`}</div><time>{new Date(m.created_at).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}</time></div>)}
              {!messages.length && <p className="muted empty-list">No messages yet. Say hello.</p>}</div>
            <form className="composer" onSubmit={sendMessage}><input value={messageText} onChange={e => setMessageText(e.target.value)} placeholder="Write a message…" maxLength={4000} aria-label="Message" /><button className="send" disabled={!messageText.trim()}>➤</button></form>
          </>}
        </section>
      </div>
      <footer className="footer">ChatWave development starter · Keep database access protected with RLS.</footer>
    </main>
  );
}
