# ChatWave + Supabase (Next.js starter)

## Features included
- Next.js app structure with TypeScript
- Supabase browser and server client helpers using `@supabase/ssr`
- Real Supabase phone OTP request and verification UI
- Chat list and message interface
- PostgreSQL schema for profiles, conversations, members and messages
- RLS policies for basic private conversation membership
- RPC function to create/reuse a direct conversation
- Realtime subscription for message table changes

## Setup
1. Install Node.js (LTS) on a computer.
2. Extract this folder and open a terminal inside it.
3. Copy `.env.example` to `.env.local`.
4. Set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` to your Supabase project's values.
5. Run `npm install`.
6. In Supabase Dashboard, enable Phone auth and configure an SMS provider.
7. Run `supabase/schema.sql` in the Supabase SQL Editor.
8. In Supabase Dashboard, enable Realtime for `public.messages` if the SQL script did not do it.
9. Run `npm run dev` and open the local URL printed by Next.js.

## Important limitations
- This is a development starter, not a fully tested production app.
- Group creation, membership management, typing indicators, online presence, receipts, media storage policies, push notifications, WebRTC voice/video calls and group media routing are not implemented yet.
- Profile phone lookup is intentionally simple and can reveal phone numbers to signed-in users. Before production, replace it with a privacy-conscious contact-discovery design.
- The RLS schema should receive a careful security review and tests before handling real private messages.
- SMS costs and delivery depend on your configured provider and region.
- Do not put Supabase secret keys in `NEXT_PUBLIC_*` variables or browser code.
- `@supabase/ssr` is for cookie-aware server-side sessions; `@supabase/supabase-js` is the general Supabase client.
- The shadcn registry command from the user's notes is optional and not needed by this starter.
