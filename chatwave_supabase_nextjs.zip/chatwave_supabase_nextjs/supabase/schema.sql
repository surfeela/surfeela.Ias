-- ChatWave starter schema for Supabase PostgreSQL.
-- Run this in Supabase Dashboard -> SQL Editor.
-- Review privacy requirements before using with real users.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  phone text unique,
  display_name text not null default '',
  avatar_path text,
  created_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('direct','group')),
  title text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('member','admin')),
  joined_at timestamptz not null default now(),
  primary key (conversation_id,user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete restrict,
  body text,
  message_type text not null default 'text' check (message_type in ('text','image','video','audio','file','system')),
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  constraint messages_body_or_media check (body is not null or message_type <> 'text')
);
create index if not exists messages_conversation_created_idx
  on public.messages(conversation_id, created_at);

alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;

-- Profiles: authenticated users can read profiles to discover contacts.
-- For production, consider a separate discoverable directory and privacy controls.
create policy "signed in users can read profiles"
on public.profiles for select to authenticated using (true);

create policy "users can update own profile"
on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create policy "users can read conversations they belong to"
on public.conversations for select to authenticated
using (exists (
  select 1 from public.conversation_members cm
  where cm.conversation_id = id and cm.user_id = auth.uid()
));

-- A user can read their own membership rows. This avoids recursive RLS
-- when the conversations policy checks membership.
create policy "users can read own membership rows"
on public.conversation_members for select to authenticated
using (user_id = auth.uid());

create policy "members can read messages"
on public.messages for select to authenticated
using (exists (
  select 1 from public.conversation_members cm
  where cm.conversation_id = messages.conversation_id and cm.user_id = auth.uid()
));

create policy "members can send messages as themselves"
on public.messages for insert to authenticated
with check (
  sender_id = auth.uid()
  and exists (
    select 1 from public.conversation_members cm
    where cm.conversation_id = messages.conversation_id and cm.user_id = auth.uid()
  )
);

create policy "sender can soft delete own message"
on public.messages for update to authenticated
using (sender_id = auth.uid())
with check (sender_id = auth.uid());

-- Create a profile row when Supabase Auth creates a user.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, phone, display_name)
  values (new.id, new.phone, '')
  on conflict (id) do update set phone = excluded.phone;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_chatwave on auth.users;
create trigger on_auth_user_created_chatwave
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Only the logged-in user can request a direct conversation with another existing user.
-- Memberships are inserted inside this function, not directly from the client.
create or replace function public.create_direct_conversation(other_user_id uuid)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  new_conversation_id uuid;
begin
  if auth.uid() is null then
    raise exception 'You must be signed in';
  end if;
  if other_user_id is null or other_user_id = auth.uid() then
    raise exception 'Choose another user';
  end if;
  if not exists (select 1 from public.profiles p where p.id = other_user_id) then
    raise exception 'User not found';
  end if;

  -- Reuse an existing direct conversation with exactly these two members.
  select c.id into new_conversation_id
  from public.conversations c
  where c.kind = 'direct'
    and exists (select 1 from public.conversation_members a where a.conversation_id = c.id and a.user_id = auth.uid())
    and exists (select 1 from public.conversation_members b where b.conversation_id = c.id and b.user_id = other_user_id)
    and (select count(*) from public.conversation_members n where n.conversation_id = c.id) = 2
  limit 1;

  if new_conversation_id is not null then
    return new_conversation_id;
  end if;

  insert into public.conversations(kind, created_by)
  values ('direct', auth.uid())
  returning id into new_conversation_id;

  insert into public.conversation_members(conversation_id,user_id,role)
  values (new_conversation_id,auth.uid(),'member'),
         (new_conversation_id,other_user_id,'member');

  return new_conversation_id;
end;
$$;

revoke all on function public.create_direct_conversation(uuid) from public;
grant execute on function public.create_direct_conversation(uuid) to authenticated;

-- Supabase Realtime: enable messages for live updates if not already enabled.
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'messages'
  ) then
    alter publication supabase_realtime add table public.messages;
  end if;
exception when undefined_object then
  raise notice 'supabase_realtime publication not found; enable Realtime for messages in Dashboard.';
end $$;

-- Note: group creation, group membership management, read receipts, presence,
-- storage policies, push notifications and WebRTC call signaling are later stages.
